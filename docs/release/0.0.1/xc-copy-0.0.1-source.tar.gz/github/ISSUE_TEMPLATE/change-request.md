---
name: 📝 Change Request
about: "A template for non-feature requests."
---

# Scope

What needs to change?

# Reason

Why is this a good change?

# Impact

Who will be impacted?
How will they be impacted?

# Notes
