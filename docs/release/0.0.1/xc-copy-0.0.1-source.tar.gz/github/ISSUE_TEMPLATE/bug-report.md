---
name: 🐞 Bug Report
about: "A template for bug reports."
---

# Observation

How did the software behave?

# Expectation

How was the software supposed to behave?

# Reproduction

How can the behaviour be reproduced?

# Notes
