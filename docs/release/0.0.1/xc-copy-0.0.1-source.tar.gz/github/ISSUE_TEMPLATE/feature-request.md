---
name: 🌱 Feature Request
about: "A template for feature requests."
---

# Scope

What is the feature?

# Reason

Why is this a good feature?

# Impact

Who will be impacted?
How will they be impacted?

# Notes
